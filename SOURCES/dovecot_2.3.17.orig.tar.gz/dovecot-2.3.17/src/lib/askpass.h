#ifndef ASKPASS_H
#define ASKPASS_H

void askpass(const char *prompt, char *buf, size_t buf_size);
const char *t_askpass(const char *prompt);

#endif
