#ifndef POP3_LOGIN_SETTINGS_H
#define POP3_LOGIN_SETTINGS_H

extern const struct setting_parser_info *pop3_login_setting_roots[];

#endif
