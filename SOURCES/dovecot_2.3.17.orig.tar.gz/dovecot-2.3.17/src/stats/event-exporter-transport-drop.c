/* Copyright (c) 2019 Dovecot authors, see the included COPYING file */

#include "lib.h"
#include "event-exporter.h"

void event_export_transport_drop(const struct exporter *exporter ATTR_UNUSED,
				 const buffer_t *buf ATTR_UNUSED)
{
}
